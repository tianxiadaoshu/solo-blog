title: （测试）从顶点小说下载小说的python代码
date: '2019-10-05 19:38:48'
updated: '2019-10-05 19:41:46'
tags: [测试]
permalink: /articles/2019/10/05/1570275528496.html
---
从顶点小说

```html
https://www.booktxt.net/
```

下载小说的python代码，仅仅是一个可执行的代码，不具备输入目标URL的能力，需要直接更改源代码

需要提供的目标URL是小说的目录URL，例如 https://www.booktxt.net/9_9544/ 

![](https://img-blog.csdnimg.cn/20190324215235898.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3RpYW54aWFkYW9zaHU=,size_16,color_FFFFFF,t_70)![null](data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==)​

  

下面是代码：

```python
# -*- coding: utf-8 -*-
import os
import re
import time
import requests
import datetime
import threadpool
from bs4 import BeautifulSoup


resultURLs = list()
resultTitles = list()
haveSpiderURLs = list()


# 获取指定url的response对象
def get_request(url):
    try:
        in_page = requests.get(url, timeout=(3, 7))
        # 如果content-type不为text/html就直接返回0
        if re.findall('.*text/html.*', in_page.headers["Content-Type"]):
            return in_page
        return 0
    except requests.exceptions.ConnectionError:
        print("请求错误ConnectionError", str(requests.exceptions.ConnectionError))
        time.sleep(3)
        return 0
    except requests.exceptions.ChunkedEncodingError:
        print("请求错误ChunkedEncodingError", str(requests.exceptions.ChunkedEncodingError))
        time.sleep(3)
        return 0
    except Exception as e:
        print("请求错误", str(e))
        time.sleep(3)
        return 0


def not_empty(s):
    return s and s.strip()


# 将多层嵌套list转为单层
def list_flatten(src):
    tmp = []
    for i in src:
        if type(i) is not list:
            tmp.append(i)
        else:
            tmp.extend(list_flatten(i))
    return tmp


# 写入到文本
def write_url_txt(chapter_title, chapter_text, in_txt_location):
    in_file_writer = open(in_txt_location, mode='a', encoding="UTF-8")
    in_file_writer.write(chapter_title + "\n")
    in_file_writer.write(chapter_text + "\n")
    in_file_writer.close()


def get_page(in_current_url):

    tem_page = get_request(in_current_url)
    if tem_page == 0:
        tem_page = get_request(in_current_url)

    print(datetime.datetime.now(), "爬取页面，URL为： " + in_current_url)
    in_page = tem_page.text
    if tem_page.encoding == 'ISO-8859-1':
        encodings = requests.utils.get_encodings_from_content(tem_page.text)
        if encodings:
            encoding = encodings[0]
        else:
            encoding = tem_page.apparent_encoding
        # encode_content = tem_page.content.decode(encoding, 'replace').encode('utf-8', 'replace')
        if encoding is None:
            return 0
        in_page = tem_page.content.decode(encoding, 'replace')  # 如果设置为replace，则会用?取代非法字符；
    return in_page


def get_and_write_chapter(tem_chapter_url):
    global chapters_list
    global write_list
    chapter_url = current_url + tem_chapter_url
    chapter_page = get_page(chapter_url)
    chapter_page_soup = BeautifulSoup(chapter_page, 'lxml')
    chapter_text_div = chapter_page_soup.find(name="div", attrs={"id": "content"})
    chapter_text_div_str = str(chapter_text_div).replace("<br/><br/>", "\n")
    chapter_text_div_str = chapter_text_div_str.replace("<div id=\"content\">", "")
    chapter_text_div_str = chapter_text_div_str.replace("</div>", "")
    write_list[tem_chapter_url] = chapters_list[tem_chapter_url] + "\n" + chapter_text_div_str + "\n"


if __name__ == "__main__":

    chapters_list = {}

    # 需要爬取的小说的目录url
    current_url = "https://www.booktxt.net/9_9544/"
    # 保存的文件路径
    txt_location = "晚钟教会.txt"
    page = get_page(current_url)
    page_soup = BeautifulSoup(page, 'lxml')

    chapters = page_soup.find(name="div", attrs={"id": "list"})
    href_list = chapters.find_all(name="a")

    for href in href_list:
        chapters_list[href["href"]] = href.text
    write_list = {}

    start_time = datetime.datetime.now()
    print(start_time, "开始爬取章节")

    pool = threadpool.ThreadPool(32)  # 线程池设置,最多同时跑两个线程

    tasks = threadpool.makeRequests(get_and_write_chapter, chapters_list.keys())
    # makeRequests构造线程task请求,第一个参数是线程函数,第二个是参数数组
    [pool.putRequest(task) for task in tasks]
    # 列表推导式,putRequest向线程池里加task,让pool自己去调度task
    pool.wait()  # 等所有任务结束

    end_time = datetime.datetime.now()
    print(end_time, "结束爬取章节")
    print("总用时", end_time - start_time)
    file_writer = open(txt_location, mode='a', encoding="UTF-8")

    for tem_url in sorted(write_list):
        file_writer.write(write_list[tem_url])
    file_writer.close()
    print("小说爬取完成，写入文件：" + os.path.abspath(txt_location))

```

