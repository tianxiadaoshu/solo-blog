title: （测试）简单的spring boot的Java文件分享代码
date: '2019-10-05 20:00:48'
updated: '2019-10-05 20:00:48'
tags: [Java, 测试, 文件共享]
permalink: /articles/2019/10/05/1570276848184.html
---
使用了spring boot2搭建项目，这个软件非常简单、简陋就一个html界面，完全没有权限控制，纯粹的是用作个人用途，只是本人写了用来共享电脑上的文件到平板和手机上用的。

使用了Java8

[https://github.com/tianxiadaoshu/fileshare-server](https://github.com/tianxiadaoshu/fileshare-server)

* 2019/3/28 增加了多文件上传、删除文件（夹）、新建文件夹功能
* 增加了共享文件夹的功能
* 增加了直接获取下载链接的功能
